-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 05 dec 2018 om 10:22
-- Serverversie: 5.7.21
-- PHP-versie: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `storage`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `amount`
--

DROP TABLE IF EXISTS `amount`;
CREATE TABLE IF NOT EXISTS `amount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `amount`
--

INSERT INTO `amount` (`id`, `amount`) VALUES
(1, '2.00'),
(2, '1.00'),
(3, '15.00'),
(4, '4.00'),
(5, '5.00'),
(6, '6.00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `hours`
--

DROP TABLE IF EXISTS `hours`;
CREATE TABLE IF NOT EXISTS `hours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hours` int(5) NOT NULL,
  `time` bit(1) NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `hours`
--

INSERT INTO `hours` (`id`, `hours`, `time`, `startTime`, `endTime`) VALUES
(1, 10, b'0', '08:00:00', '19:00:00'),
(2, 7, b'0', '06:00:00', '20:00:00'),
(3, 2, b'0', '06:00:00', '18:00:00'),
(4, 3, b'0', '06:00:00', '19:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `items`
--

INSERT INTO `items` (`id`, `amount`, `name`) VALUES
(1, '50.00', 'Abacavir'),
(2, '20.00', 'Acyclovir'),
(3, '30.00', 'Alemtuzumab '),
(23, '432.00', 'Alendronate'),
(24, '34.00', 'Allopurinol');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `zipcode` varchar(50) NOT NULL,
  `phone` int(15) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `admin` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `age`, `address`, `zipcode`, `phone`, `email`, `admin`) VALUES
(12, 'nordin', '1b57G3Vr62iiBjtUyir8kQ==', 'nordin', 21, 'Boomheide 1', '3060LA', 104052077, 'nordinleije@gmail.com', b'1'),
(30, 'jeff', '+KIC5mgezBTpQ/9ahA2x/w==', 'jeff', 45, 'steenheide 4', '4567LG', 104502077, 'jeff@gmail.com', b'0'),
(31, 'ben', 'RdnK1GVdnzuk7vX1Xhz1gw==', 'ben', 69, 'schpstraat 45', '6934XD', 20459271, 'ben@hotmail.com', b'0');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `user_items`
--

DROP TABLE IF EXISTS `user_items`;
CREATE TABLE IF NOT EXISTS `user_items` (
  `userid` int(11) NOT NULL,
  `itemsid` int(11) NOT NULL,
  `amountid` int(11) NOT NULL,
  `hoursid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`itemsid`,`amountid`,`hoursid`),
  KEY `userid` (`userid`),
  KEY `itemsid` (`itemsid`),
  KEY `amountid` (`amountid`),
  KEY `hoursid` (`hoursid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `user_items`
--

INSERT INTO `user_items` (`userid`, `itemsid`, `amountid`, `hoursid`) VALUES
(12, 23, 1, 1),
(31, 1, 2, 2),
(31, 23, 4, 3);

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `user_items`
--
ALTER TABLE `user_items`
  ADD CONSTRAINT `user_items_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `user_items_ibfk_2` FOREIGN KEY (`itemsid`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `user_items_ibfk_3` FOREIGN KEY (`amountid`) REFERENCES `amount` (`id`),
  ADD CONSTRAINT `user_items_ibfk_4` FOREIGN KEY (`hoursid`) REFERENCES `hours` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
