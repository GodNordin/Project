﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Timer
{
    class Mysqlquery
    {
        readonly MySqlConnection con = new MySqlConnection("server=localhost;user id=root;password=;persistsecurityinfo=True;database=storage;SslMode=none");

        public void Select(string command, string value, int textbox)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void CreateItems(string command, string value, decimal textbox, string value2, string textbox2)
        {            
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.Parameters.AddWithValue(value2, textbox2);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void CreateUsers(string command, string value, string textbox, string value2, string textbox2, string value3, string textbox3, string value4, int textbox4, string value5, string textbox5, string value6, string textbox6, string value7, int textbox7, string value8, string textbox8)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.Parameters.AddWithValue(value2, textbox2);
            cmd.Parameters.AddWithValue(value3, textbox3);
            cmd.Parameters.AddWithValue(value4, textbox4);
            cmd.Parameters.AddWithValue(value5, textbox5);
            cmd.Parameters.AddWithValue(value6, textbox6);
            cmd.Parameters.AddWithValue(value7, textbox7);
            cmd.Parameters.AddWithValue(value8, textbox8);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void CreateUserItems(string command, string value, int textbox, string value2, int textbox2, string value3, int textbox3, string value4, int textbox4)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.Parameters.AddWithValue(value2, textbox2);
            cmd.Parameters.AddWithValue(value3, textbox3);
            cmd.Parameters.AddWithValue(value4, textbox4);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void EditItems(string command, string value, decimal textbox, string value2, string textbox2, string id, int textbox3)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.Parameters.AddWithValue(value2, textbox2);
            cmd.Parameters.AddWithValue(id, textbox3);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void EditUsers(string command, string value, string textbox, string value2, string textbox2, string value3, string textbox3, string value4, int textbox4, string value5, string textbox5, string value6, string textbox6, string value7, int textbox7, string value8, string textbox8, string value9, int textbox9)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.Parameters.AddWithValue(value2, textbox2);
            cmd.Parameters.AddWithValue(value3, textbox3);
            cmd.Parameters.AddWithValue(value4, textbox4);
            cmd.Parameters.AddWithValue(value5, textbox5);
            cmd.Parameters.AddWithValue(value6, textbox6);
            cmd.Parameters.AddWithValue(value7, textbox7);
            cmd.Parameters.AddWithValue(value8, textbox8);
            cmd.Parameters.AddWithValue(value9, textbox9);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void EditUserItems(string command, string value, int textbox, string value2, int textbox2, string value3, int textbox3, string value4, int textbox4)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.Parameters.AddWithValue(value2, textbox2);
            cmd.Parameters.AddWithValue(value3, textbox3);
            cmd.Parameters.AddWithValue(value4, textbox4);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(string command, string value, int textbox)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(command, con);
            cmd.Parameters.AddWithValue(value, textbox);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public BindingSource Data(string query)
        {
            CloseConnection();
            DataTable table = new DataTable();
            MySqlDataAdapter MyDA = new MySqlDataAdapter();
            string sqlSelectAll = query;
            MySqlCommand mySql = new MySqlCommand(sqlSelectAll, con);
            MyDA.SelectCommand = new MySqlCommand(sqlSelectAll, con);
            MyDA.Fill(table);

            BindingSource bSource = new BindingSource
            {
                DataSource = table
            };
            return bSource;
        }

        public MySqlDataReader Reader(string query, string value, object id)
        {
            CloseConnection();
            con.Open();
            MySqlCommand cmd;
            cmd = new MySqlCommand(query, con);
            cmd.Parameters.AddWithValue(value, id);
            cmd.ExecuteNonQuery();
            MySqlDataReader sdr = cmd.ExecuteReader();
            return sdr;
        }

        public void SelectAllUserItems(string command, DataGridView dgv)
        {
            CloseConnection();
            DataTable table = new DataTable();
            table.Clear();

            try
            {
                con.Open();
                MySqlCommand cmd;
                cmd = new MySqlCommand(command, con);

                cmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(table);

                MySqlCommandBuilder cb = new MySqlCommandBuilder(da);

                dgv.DataSource = table;
                dgv.DataMember = table.TableName;
                dgv.AutoResizeColumns();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con != null) con.Close();
            }
        }

        public void SelectAllItems(string command, string value, int id, DataGridView dgv)
        {
            CloseConnection();
            DataTable table = new DataTable();
            table.Clear();

            try
            {
                con.Open();
                MySqlCommand cmd;
                cmd = new MySqlCommand(command, con);
                cmd.Parameters.AddWithValue(value, id);

                cmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(table);

                MySqlCommandBuilder cb = new MySqlCommandBuilder(da);

                dgv.DataSource = table;
                dgv.DataMember = table.TableName;
                dgv.AutoResizeColumns();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con != null) con.Close();
            }
        }

        private void CloseConnection()
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
}