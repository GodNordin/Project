﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Timer
{
    public partial class Login : Form
    {
        Mysqlquery mysqlquery = new Mysqlquery();
        readonly MySqlConnection con = new MySqlConnection("server=localhost;user id=root;password=;persistsecurityinfo=True;database=storage;SslMode=none");

        private void CloseConnection()
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

        public Login()
        {
            InitializeComponent();
            TbPassword.PasswordChar = '*';
        }

        private void GetHoursId()
        {
            Admin.hoursid = new List<int>();
            MySqlDataReader msdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid=@userid", "@userid", Admin.userid);
            while (msdr.Read())
            {
                Admin.hoursid.Add(msdr.GetInt32(3));
            }
            msdr.NextResult();
        }

        private void GetHours()
        {
            Admin.hours = new List<int>();
            foreach (int i in Admin.hoursid)
            {
                MySqlDataReader reader = mysqlquery.Reader("SELECT * FROM hours WHERE id=@id ORDER BY hours ASC", "@id", i);
                while(reader.Read())
                {
                    Admin.hours.Add(reader.GetInt32(1));
                }
                reader.NextResult();
            }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TbLogin.Text) || string.IsNullOrEmpty(TbPassword.Text))
            {
                MessageBox.Show("username or password is missing");
            }
            else
            {
                string Password = "";
                bool IsExist = false;
                MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM users WHERE username=@username", "@username", TbLogin.Text);
                if (sdr.Read())
                {
                    Password = sdr.GetString(2);
                    Admin.admin = sdr.GetInt32(9);
                    Admin.userid = sdr.GetInt32(0);
                    Admin.user = sdr.GetString(1);
                    IsExist = true;
                    CloseConnection();
                }
                GetHoursId();
                GetHours();
                if (IsExist)
                {
                    if (Helper.Decrypt(Password).Equals(TbPassword.Text))
                    {
                        MessageBox.Show("Login Success", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Form1 frm1 = new Form1();
                        frm1.Show();
                        Hide();
                    }
                    else
                    {
                        MessageBox.Show("Password is wrong!...", "error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the valid credentials", "error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
