﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Timer
{
    public partial class Form1 : Form
    {
        Mysqlquery mysqlquery = new Mysqlquery();
        readonly MySqlConnection con = new MySqlConnection("server=localhost;user id=root;password=;persistsecurityinfo=True;database=storage;SslMode=none");

        public Form1()
        {
            InitializeComponent();
            DgvItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DgvItems.MultiSelect = false;
            if (Admin.admin == 1)
            {
                BtnShow.Visible = true;
                BtnUserItems.Visible = true;
                BtnItems.Visible = true;
            }
            else
            {
                this.Size = new Size(600, 300);
                BtnUsers.Location = new Point(520, 170);
                BtnLogout.Location = new Point(520, 10);
            }
            TbUser.Text = Admin.user;
            InitTimer();
            MySQL_ToDatagridview();
        }

        private void CloseConnection()
        {
            if (con != null && con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

        private List<int> SelectItems()
        {
            List<int> intList = new List<int>();
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid=@usersid", "@usersid", Admin.userid);
            while (sdr.Read())
            {
                intList.Add(sdr.GetInt32(1));
            }
            sdr.NextResult();
            return intList;
        }

        private List<int> SelectAmount()
        {
            List<int> intList = new List<int>();
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid=@usersid", "@usersid", Admin.userid);
            while (sdr.Read())
            {
                intList.Add( sdr.GetInt32(2) );   
            }
            sdr.NextResult();
            return intList;
        }

        private List<int> SelectHours()
        {
            List<int> intList = new List<int>();
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid=@usersid", "@usersid", Admin.userid);
            while (sdr.Read())
            {
                intList.Add(sdr.GetInt32(3));
            }
            sdr.NextResult();
            return intList;
        }

        public int Amountid()
        {
            int i = 0;
            MySqlDataReader msdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid=@id", "@id", Admin.userid);
            if(msdr.Read())
            {
                int id = msdr.GetInt32(2);
                CloseConnection();
                MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM amount WHERE id=@id", "@id", id);
                if (sdr.Read())
                {
                    i = sdr.GetInt32(0);
                    CloseConnection();
                }
            }
            return i;
        }

        public int Itemsid()
        {
            int i = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid = @itemsid", "@itemsid", Admin.userid);
            if(sdr.Read())
            {
                i = sdr.GetInt32(1);
                CloseConnection();
            }
            return i;
        }

        private void MySQL_ToDatagridview()
        {
            if(Admin.admin == 1)
            {
                DgvItems.DataSource = mysqlquery.Data("SELECT DISTINCT users.username, amount.amount, items.name, hours.hours, hours.startTime, hours.endTime FROM user_items LEFT JOIN users ON user_items.userid = users.id LEFT JOIN amount ON user_items.amountid = amount.id LEFT JOIN items ON user_items.itemsid = items.id LEFT JOIN hours ON user_items.hoursid = hours.id");
            }
            else
            {
                mysqlquery.SelectAllItems("SELECT DISTINCT users.username, amount.amount, items.name, hours.hours, hours.startTime, hours.endTime FROM user_items LEFT JOIN users ON user_items.userid = users.id LEFT JOIN amount ON user_items.amountid = amount.id LEFT JOIN items ON user_items.itemsid = items.id LEFT JOIN hours ON user_items.hoursid = hours.id WHERE user_items.userid=@userid", "@userid", Admin.userid, DgvItems);
            }         
        }

        public class AutoClosingMessageBox
        {
            System.Threading.Timer _timeoutTimer;
            readonly string _caption;
            AutoClosingMessageBox(string text, string caption, int timeout)
            {
                _caption = caption;
                _timeoutTimer = new System.Threading.Timer(OnTimerElapsed,
                    null, timeout, System.Threading.Timeout.Infinite);
                using (_timeoutTimer)
                    MessageBox.Show(text, caption);
            }
            public static void Show(string text, string caption, int timeout)
            {
                new AutoClosingMessageBox(text, caption, timeout);
            }
            void OnTimerElapsed(object state)
            {
                IntPtr mbWnd = FindWindow("#32770", _caption); // lpClassName is #32770 for MessageBox
                if (mbWnd != IntPtr.Zero)
                    SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                _timeoutTimer.Dispose();
            }
            const int WM_CLOSE = 0x0010;
            [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
            static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
            static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
        }

        public void InitTimer()
        {
            System.Timers.Timer timer = new System.Timers.Timer
            {
                Interval = 10000
            };
            timer.Elapsed += new System.Timers.ElapsedEventHandler(this.OnTimer);
            timer.Start();
        }

        public void OnTimer(object sender, System.Timers.ElapsedEventArgs args)
        {
            UpdateTime();
        }

        private void UpdateTime()
        {
            List<int> hours = new List<int>();
            foreach(int hoursid in Admin.hoursid)
            {
                MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM hours WHERE id=@id", "@id", hoursid);
                while (sdr.Read())
                {
                    hours.Add(sdr.GetInt32(2));
                }
                sdr.NextResult();
                foreach (int i in hours)
                {
                    if (i == 1)
                    {
                        MessageBox.Show("it is time");
                        Time();
                    }
                }
            }
        }

        private void Time()
        {
            mysqlquery.Select("UPDATE hours SET time=0 WHERE time=@time", "@time" , 1);
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            MySQL_ToDatagridview();
        }

        private void BtnUsers_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            users.Show();
            Hide();
        }

        private void BtnUserItems_Click(object sender, EventArgs e)
        {
            UserItems userItems = new UserItems();
            userItems.Show();
            Hide();
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            Hide();
        }

        private void DgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = DgvItems.Rows[index];
        }

        private void TBCreateName_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TBCreateAmount_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void TbEditName_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnItems_Click(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Hide();
        }
    }
}