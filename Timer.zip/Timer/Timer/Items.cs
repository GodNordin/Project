﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Timer
{
    public partial class Items : Form
    {
        Mysqlquery mysqlquery = new Mysqlquery();

        public Items()
        {
            InitializeComponent();
            DgvItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DgvItems.MultiSelect = false;
        }

        private new void Show()
        {
            DgvItems.DataSource = mysqlquery.Data("SELECT * FROM items");
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            Show();
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void BtnTimer_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void BtnUserItems_Click(object sender, EventArgs e)
        {
            UserItems userItems = new UserItems();
            userItems.Show();
            this.Hide();
        }

        private void BtnUsers_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            users.Show();
            this.Hide();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.CreateItems("INSERT INTO items(amount, name) VALUES (@amount, @name)", "@amount", Convert.ToDecimal(TbCreateAmount.Text), "@name", TbCreateName.Text);
                Show();
            }
            catch(Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.EditItems("UPDATE items SET amount=@amount, name=@name WHERE id=@id", "@amount", Convert.ToDecimal(TbEditAmount.Text), "@name", TbEditName.Text, "@id", Convert.ToInt32(TbEditId.Text));
                Show();
            }
            catch(Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.Delete("DELETE FROM items WHERE id=@id", "@id", Convert.ToInt32(TbDelete.Text));
                Show();
            }
            catch(Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void DgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = DgvItems.Rows[index];
            TbEditAmount.Text = selectedRow.Cells[1].Value.ToString();
            TbEditName.Text = selectedRow.Cells[2].Value.ToString();
            TbDelete.Text = selectedRow.Cells[0].Value.ToString();
            TbEditId.Text = selectedRow.Cells[0].Value.ToString();
        }

        private void TbCreateAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void TbEditAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void TbCreateName_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditName_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }
    }
}
