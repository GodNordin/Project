﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Timer
{
    public partial class UserItems : Form
    {
        Mysqlquery mysqlquery = new Mysqlquery();

        public UserItems()
        {
            InitializeComponent();
            DgvUserItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DgvUserItems.MultiSelect = false;
            if (Admin.admin == 1)
            {
                BtnCreate.Visible = true;
                BtnEdit.Visible = true;
                BtnDelete.Visible = true;
                TbCreateUsers.Visible = true;
                TbCreateItems.Visible = true;
                TbCreateAmount.Visible = true;
                TbEditAmount.Visible = true;
                TbEditItems.Visible = true;
                TbEditUsers.Visible = true;
                TbDelete.Visible = true;
                LblCreateUsers.Visible = true;
                LblCreateItems.Visible = true;
                LblCreateAmount.Visible = true;
                LblEditAmount.Visible = true;
                LblEditItems.Visible = true;
                LblDelete.Visible = true;
                LblEditUsers.Visible = true;
            }
        }

        private int SelectUserid()
        {
            int userid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM users WHERE username=@username", "@username", TbCreateUsers.Text);
            if(sdr.Read())
            {
                userid = sdr.GetInt32(0);
            }
            return userid;
        }

        private int SelectItemsid()
        {
            int itemsid = 0;
            MySqlDataReader Sdr = mysqlquery.Reader("SELECT * FROM items WHERE name=@name", "@name", TbCreateItems.Text);
            if(Sdr.Read())
            {
                itemsid = Sdr.GetInt32(0);
            }
            return itemsid;

        }

        private int SelectAmountid()
        {
            int amountid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM amount WHERE amount=@amount", "@amount", Convert.ToDecimal(TbCreateAmount.Text));
            if(sdr.Read())
            {
                amountid = sdr.GetInt32(0);
            }
            return amountid;

        }

        private int SelectHoursid()
        {
            int hoursid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM hours WHERE hours=@hours", "@hours", Convert.ToInt32(TbCreateHours.Text));
            if(sdr.Read())
            {
                hoursid = sdr.GetInt32(0);
            }
            return hoursid;
        }

        private int EditUserid()
        {
            int userid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM users WHERE username=@username", "@username", TbEditUsers.Text);
            if (sdr.Read())
            {
                userid = sdr.GetInt32(0);
            }
            return userid;
        }

        private int EditItemsid()
        {
            int itemsid = 0;
            MySqlDataReader Sdr = mysqlquery.Reader("SELECT * FROM items WHERE name=@name", "@name", TbEditItems.Text);
            if (Sdr.Read())
            {
                itemsid = Sdr.GetInt32(0);
            }
            return itemsid;

        }

        private int EditAmountid()
        {
            int amountid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM amount WHERE amount=@amount", "@amount", Convert.ToDecimal(TbEditAmount.Text));
            if (sdr.Read())
            {
                amountid = sdr.GetInt32(0);
            }
            return amountid;

        }

        private int EditHoursid()
        {
            int hoursid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM hours WHERE hours=@hours", "@hours", Convert.ToInt32(TbEditHours.Text));
            if (sdr.Read())
            {
                hoursid = sdr.GetInt32(0);
            }
            return hoursid;
        }

        private int Delete()
        {
            int userid = 0;
            MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM user_items WHERE userid=@userid", "@userid", TbDelete.Text);
            if (sdr.Read())
            {
                userid = sdr.GetInt32(0);
            }
            return userid;
        }

        private void SelectAll()
        {
            mysqlquery.SelectAllUserItems("SELECT DISTINCT user_items.userid, users.id, users.username, user_items.itemsid, items.id, items.name, user_items.amountid, amount.id, amount.amount, user_items.hoursid, hours.id, hours.hours FROM user_items LEFT JOIN users ON user_items.userid = users.id LEFT JOIN items ON user_items.itemsid = items.id LEFT JOIN amount ON user_items.amountid = amount.id LEFT JOIN hours ON user_items.hoursid = hours.id", DgvUserItems);
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            SelectAll();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.CreateUserItems("INSERT INTO user_items(userid, itemsid, amountid, hoursid) VALUES (@userid, @itemsid, @amountid, @hoursid)", "@userid", SelectUserid(), "@itemsid", SelectItemsid(), "@amountid", SelectAmountid(), "@hoursid", SelectHoursid());
                MessageBox.Show("Recored edited created");
                SelectAll();
            }
            catch(Exception E)
            {
                MessageBox.Show(E.Message);
            }          
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.EditUserItems("UPDATE user_items SET amountid = @amountid WHERE userid=@userid AND itemsid=@itemsid AND hoursid=@hoursid", "@userid", EditUserid(), "@itemsid", EditItemsid(), "@amountid", EditAmountid(), "@hoursid", EditHoursid());
                mysqlquery.EditUserItems("UPDATE user_items SET itemsid = @itemsid WHERE userid=@userid AND amountid=@amountid AND hoursid=@hoursid", "@userid", EditUserid(), "@itemsid", EditItemsid(), "@amountid", EditAmountid(), "@hoursid", EditHoursid());
                mysqlquery.EditUserItems("UPDATE user_items SET hoursid = @hoursid WHERE userid=@userid AND itemsid=@itemsid AND amountid=@amountid", "@userid", EditUserid(), "@itemsid", EditItemsid(), "@amountid", EditAmountid(), "@hoursid", EditHoursid());
                MessageBox.Show("Recored edited created");
                SelectAll();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + " fill in all textboxs");
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.Delete("DELETE FROM user_items WHERE userid=@userid", "@userid", Delete());
                MessageBox.Show("Recored deleted created");
                SelectAll();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + " fill in all textboxs");
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            Hide();
        }

        private void BtnTimer_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Hide();
        }

        private void BtnUsers_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            users.Show();
            Hide();
        }

        private void DgvUserItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = DgvUserItems.Rows[index];
            TbEditUsers.Text = selectedRow.Cells[2].Value.ToString();
            TbEditItems.Text = selectedRow.Cells[5].Value.ToString();
            TbEditAmount.Text = selectedRow.Cells[8].Value.ToString();
            TbEditHours.Text = selectedRow.Cells[11].Value.ToString();
            TbDelete.Text = selectedRow.Cells[0].Value.ToString();
        }

        private void TbCreateUsers_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreateItems_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreateAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void TbCreateHours_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }
        }

        private void TbEditUsers_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditItems_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void TbEditHours_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }
        }

        private void BtnItems_Click(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Hide();
        }
    }
}
