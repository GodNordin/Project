﻿namespace Timer
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DgvUsers = new System.Windows.Forms.DataGridView();
            this.BtnShow = new System.Windows.Forms.Button();
            this.BtnCreate = new System.Windows.Forms.Button();
            this.TbCreateUsername = new System.Windows.Forms.TextBox();
            this.TbCreatePassword = new System.Windows.Forms.TextBox();
            this.TbCreateName = new System.Windows.Forms.TextBox();
            this.TbCreateAge = new System.Windows.Forms.TextBox();
            this.TbCreateAddress = new System.Windows.Forms.TextBox();
            this.TbCreateZipcode = new System.Windows.Forms.TextBox();
            this.TbCreatePhone = new System.Windows.Forms.TextBox();
            this.TbCreateEmail = new System.Windows.Forms.TextBox();
            this.LblCreateUsername = new System.Windows.Forms.Label();
            this.LblCreatePassword = new System.Windows.Forms.Label();
            this.LblCreateName = new System.Windows.Forms.Label();
            this.LblCreateAge = new System.Windows.Forms.Label();
            this.LblCreateAddress = new System.Windows.Forms.Label();
            this.LblCreateZipcode = new System.Windows.Forms.Label();
            this.LblCreatePhone = new System.Windows.Forms.Label();
            this.LblCreateEmail = new System.Windows.Forms.Label();
            this.LblEditEmail = new System.Windows.Forms.Label();
            this.LblEditPhone = new System.Windows.Forms.Label();
            this.LblEditZipcode = new System.Windows.Forms.Label();
            this.LblEditAddress = new System.Windows.Forms.Label();
            this.LblEditAge = new System.Windows.Forms.Label();
            this.LblEditName = new System.Windows.Forms.Label();
            this.LblEditPassword = new System.Windows.Forms.Label();
            this.LblEditUsername = new System.Windows.Forms.Label();
            this.TbEditEmail = new System.Windows.Forms.TextBox();
            this.TbEditPhone = new System.Windows.Forms.TextBox();
            this.TbEditZipcode = new System.Windows.Forms.TextBox();
            this.TbEditAdrress = new System.Windows.Forms.TextBox();
            this.TbEditAge = new System.Windows.Forms.TextBox();
            this.TbEditName = new System.Windows.Forms.TextBox();
            this.TbEditPassword = new System.Windows.Forms.TextBox();
            this.TbEditUsername = new System.Windows.Forms.TextBox();
            this.BtnEdit = new System.Windows.Forms.Button();
            this.TbEditId = new System.Windows.Forms.TextBox();
            this.LblEditId = new System.Windows.Forms.Label();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.TbDelete = new System.Windows.Forms.TextBox();
            this.LblDelete = new System.Windows.Forms.Label();
            this.BtnTimer = new System.Windows.Forms.Button();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.BtnUserItems = new System.Windows.Forms.Button();
            this.BtnItems = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUsers)).BeginInit();
            this.SuspendLayout();
            // 
            // DgvUsers
            // 
            this.DgvUsers.AllowUserToAddRows = false;
            this.DgvUsers.AllowUserToDeleteRows = false;
            this.DgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvUsers.Location = new System.Drawing.Point(13, 45);
            this.DgvUsers.Name = "DgvUsers";
            this.DgvUsers.ReadOnly = true;
            this.DgvUsers.RowTemplate.Height = 24;
            this.DgvUsers.Size = new System.Drawing.Size(775, 250);
            this.DgvUsers.TabIndex = 0;
            this.DgvUsers.Visible = false;
            this.DgvUsers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvUsers_CellClick);
            // 
            // BtnShow
            // 
            this.BtnShow.Location = new System.Drawing.Point(13, 302);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(75, 23);
            this.BtnShow.TabIndex = 1;
            this.BtnShow.Text = "Show";
            this.BtnShow.UseVisualStyleBackColor = true;
            this.BtnShow.Visible = false;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // BtnCreate
            // 
            this.BtnCreate.Location = new System.Drawing.Point(216, 301);
            this.BtnCreate.Name = "BtnCreate";
            this.BtnCreate.Size = new System.Drawing.Size(75, 23);
            this.BtnCreate.TabIndex = 2;
            this.BtnCreate.Text = "Create";
            this.BtnCreate.UseVisualStyleBackColor = true;
            this.BtnCreate.Visible = false;
            this.BtnCreate.Click += new System.EventHandler(this.BtnCreate_Click);
            // 
            // TbCreateUsername
            // 
            this.TbCreateUsername.Location = new System.Drawing.Point(216, 331);
            this.TbCreateUsername.MaxLength = 100;
            this.TbCreateUsername.Name = "TbCreateUsername";
            this.TbCreateUsername.ShortcutsEnabled = false;
            this.TbCreateUsername.Size = new System.Drawing.Size(100, 22);
            this.TbCreateUsername.TabIndex = 3;
            this.TbCreateUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateUsername_KeyPress);
            // 
            // TbCreatePassword
            // 
            this.TbCreatePassword.Location = new System.Drawing.Point(216, 359);
            this.TbCreatePassword.MaxLength = 100;
            this.TbCreatePassword.Name = "TbCreatePassword";
            this.TbCreatePassword.ShortcutsEnabled = false;
            this.TbCreatePassword.Size = new System.Drawing.Size(100, 22);
            this.TbCreatePassword.TabIndex = 4;
            this.TbCreatePassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreatePassword_KeyPress);
            // 
            // TbCreateName
            // 
            this.TbCreateName.Location = new System.Drawing.Point(216, 387);
            this.TbCreateName.MaxLength = 100;
            this.TbCreateName.Name = "TbCreateName";
            this.TbCreateName.ShortcutsEnabled = false;
            this.TbCreateName.Size = new System.Drawing.Size(100, 22);
            this.TbCreateName.TabIndex = 5;
            this.TbCreateName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateName_KeyPress);
            // 
            // TbCreateAge
            // 
            this.TbCreateAge.Location = new System.Drawing.Point(216, 415);
            this.TbCreateAge.MaxLength = 100;
            this.TbCreateAge.Name = "TbCreateAge";
            this.TbCreateAge.ShortcutsEnabled = false;
            this.TbCreateAge.Size = new System.Drawing.Size(100, 22);
            this.TbCreateAge.TabIndex = 6;
            this.TbCreateAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateAge_KeyPress);
            // 
            // TbCreateAddress
            // 
            this.TbCreateAddress.Location = new System.Drawing.Point(216, 443);
            this.TbCreateAddress.MaxLength = 200;
            this.TbCreateAddress.Name = "TbCreateAddress";
            this.TbCreateAddress.ShortcutsEnabled = false;
            this.TbCreateAddress.Size = new System.Drawing.Size(100, 22);
            this.TbCreateAddress.TabIndex = 7;
            this.TbCreateAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateAddress_KeyPress);
            // 
            // TbCreateZipcode
            // 
            this.TbCreateZipcode.Location = new System.Drawing.Point(216, 471);
            this.TbCreateZipcode.MaxLength = 50;
            this.TbCreateZipcode.Name = "TbCreateZipcode";
            this.TbCreateZipcode.ShortcutsEnabled = false;
            this.TbCreateZipcode.Size = new System.Drawing.Size(100, 22);
            this.TbCreateZipcode.TabIndex = 8;
            this.TbCreateZipcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateZipcode_KeyPress);
            // 
            // TbCreatePhone
            // 
            this.TbCreatePhone.Location = new System.Drawing.Point(216, 499);
            this.TbCreatePhone.MaxLength = 15;
            this.TbCreatePhone.Name = "TbCreatePhone";
            this.TbCreatePhone.ShortcutsEnabled = false;
            this.TbCreatePhone.Size = new System.Drawing.Size(100, 22);
            this.TbCreatePhone.TabIndex = 9;
            this.TbCreatePhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreatePhone_KeyPress);
            // 
            // TbCreateEmail
            // 
            this.TbCreateEmail.Location = new System.Drawing.Point(216, 527);
            this.TbCreateEmail.MaxLength = 200;
            this.TbCreateEmail.Name = "TbCreateEmail";
            this.TbCreateEmail.ShortcutsEnabled = false;
            this.TbCreateEmail.Size = new System.Drawing.Size(100, 22);
            this.TbCreateEmail.TabIndex = 10;
            this.TbCreateEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateEmail_KeyPress);
            // 
            // LblCreateUsername
            // 
            this.LblCreateUsername.AutoSize = true;
            this.LblCreateUsername.Location = new System.Drawing.Point(139, 337);
            this.LblCreateUsername.Name = "LblCreateUsername";
            this.LblCreateUsername.Size = new System.Drawing.Size(71, 17);
            this.LblCreateUsername.TabIndex = 11;
            this.LblCreateUsername.Text = "username";
            // 
            // LblCreatePassword
            // 
            this.LblCreatePassword.AutoSize = true;
            this.LblCreatePassword.Location = new System.Drawing.Point(139, 362);
            this.LblCreatePassword.Name = "LblCreatePassword";
            this.LblCreatePassword.Size = new System.Drawing.Size(68, 17);
            this.LblCreatePassword.TabIndex = 12;
            this.LblCreatePassword.Text = "password";
            // 
            // LblCreateName
            // 
            this.LblCreateName.AutoSize = true;
            this.LblCreateName.Location = new System.Drawing.Point(139, 390);
            this.LblCreateName.Name = "LblCreateName";
            this.LblCreateName.Size = new System.Drawing.Size(43, 17);
            this.LblCreateName.TabIndex = 13;
            this.LblCreateName.Text = "name";
            // 
            // LblCreateAge
            // 
            this.LblCreateAge.AutoSize = true;
            this.LblCreateAge.Location = new System.Drawing.Point(139, 418);
            this.LblCreateAge.Name = "LblCreateAge";
            this.LblCreateAge.Size = new System.Drawing.Size(32, 17);
            this.LblCreateAge.TabIndex = 14;
            this.LblCreateAge.Text = "age";
            // 
            // LblCreateAddress
            // 
            this.LblCreateAddress.AutoSize = true;
            this.LblCreateAddress.Location = new System.Drawing.Point(139, 448);
            this.LblCreateAddress.Name = "LblCreateAddress";
            this.LblCreateAddress.Size = new System.Drawing.Size(59, 17);
            this.LblCreateAddress.TabIndex = 15;
            this.LblCreateAddress.Text = "address";
            // 
            // LblCreateZipcode
            // 
            this.LblCreateZipcode.AutoSize = true;
            this.LblCreateZipcode.Location = new System.Drawing.Point(139, 471);
            this.LblCreateZipcode.Name = "LblCreateZipcode";
            this.LblCreateZipcode.Size = new System.Drawing.Size(57, 17);
            this.LblCreateZipcode.TabIndex = 16;
            this.LblCreateZipcode.Text = "zipcode";
            // 
            // LblCreatePhone
            // 
            this.LblCreatePhone.AutoSize = true;
            this.LblCreatePhone.Location = new System.Drawing.Point(139, 499);
            this.LblCreatePhone.Name = "LblCreatePhone";
            this.LblCreatePhone.Size = new System.Drawing.Size(48, 17);
            this.LblCreatePhone.TabIndex = 17;
            this.LblCreatePhone.Text = "phone";
            // 
            // LblCreateEmail
            // 
            this.LblCreateEmail.AutoSize = true;
            this.LblCreateEmail.Location = new System.Drawing.Point(139, 527);
            this.LblCreateEmail.Name = "LblCreateEmail";
            this.LblCreateEmail.Size = new System.Drawing.Size(41, 17);
            this.LblCreateEmail.TabIndex = 18;
            this.LblCreateEmail.Text = "email";
            // 
            // LblEditEmail
            // 
            this.LblEditEmail.AutoSize = true;
            this.LblEditEmail.Location = new System.Drawing.Point(353, 527);
            this.LblEditEmail.Name = "LblEditEmail";
            this.LblEditEmail.Size = new System.Drawing.Size(41, 17);
            this.LblEditEmail.TabIndex = 35;
            this.LblEditEmail.Text = "email";
            this.LblEditEmail.Visible = false;
            // 
            // LblEditPhone
            // 
            this.LblEditPhone.AutoSize = true;
            this.LblEditPhone.Location = new System.Drawing.Point(353, 499);
            this.LblEditPhone.Name = "LblEditPhone";
            this.LblEditPhone.Size = new System.Drawing.Size(48, 17);
            this.LblEditPhone.TabIndex = 34;
            this.LblEditPhone.Text = "phone";
            this.LblEditPhone.Visible = false;
            // 
            // LblEditZipcode
            // 
            this.LblEditZipcode.AutoSize = true;
            this.LblEditZipcode.Location = new System.Drawing.Point(353, 471);
            this.LblEditZipcode.Name = "LblEditZipcode";
            this.LblEditZipcode.Size = new System.Drawing.Size(57, 17);
            this.LblEditZipcode.TabIndex = 33;
            this.LblEditZipcode.Text = "zipcode";
            this.LblEditZipcode.Visible = false;
            // 
            // LblEditAddress
            // 
            this.LblEditAddress.AutoSize = true;
            this.LblEditAddress.Location = new System.Drawing.Point(353, 448);
            this.LblEditAddress.Name = "LblEditAddress";
            this.LblEditAddress.Size = new System.Drawing.Size(59, 17);
            this.LblEditAddress.TabIndex = 32;
            this.LblEditAddress.Text = "address";
            this.LblEditAddress.Visible = false;
            // 
            // LblEditAge
            // 
            this.LblEditAge.AutoSize = true;
            this.LblEditAge.Location = new System.Drawing.Point(353, 418);
            this.LblEditAge.Name = "LblEditAge";
            this.LblEditAge.Size = new System.Drawing.Size(32, 17);
            this.LblEditAge.TabIndex = 31;
            this.LblEditAge.Text = "age";
            this.LblEditAge.Visible = false;
            // 
            // LblEditName
            // 
            this.LblEditName.AutoSize = true;
            this.LblEditName.Location = new System.Drawing.Point(353, 390);
            this.LblEditName.Name = "LblEditName";
            this.LblEditName.Size = new System.Drawing.Size(43, 17);
            this.LblEditName.TabIndex = 30;
            this.LblEditName.Text = "name";
            this.LblEditName.Visible = false;
            // 
            // LblEditPassword
            // 
            this.LblEditPassword.AutoSize = true;
            this.LblEditPassword.Location = new System.Drawing.Point(353, 362);
            this.LblEditPassword.Name = "LblEditPassword";
            this.LblEditPassword.Size = new System.Drawing.Size(68, 17);
            this.LblEditPassword.TabIndex = 29;
            this.LblEditPassword.Text = "password";
            this.LblEditPassword.Visible = false;
            // 
            // LblEditUsername
            // 
            this.LblEditUsername.AutoSize = true;
            this.LblEditUsername.Location = new System.Drawing.Point(353, 334);
            this.LblEditUsername.Name = "LblEditUsername";
            this.LblEditUsername.Size = new System.Drawing.Size(71, 17);
            this.LblEditUsername.TabIndex = 28;
            this.LblEditUsername.Text = "username";
            this.LblEditUsername.Visible = false;
            // 
            // TbEditEmail
            // 
            this.TbEditEmail.Location = new System.Drawing.Point(430, 527);
            this.TbEditEmail.MaxLength = 200;
            this.TbEditEmail.Name = "TbEditEmail";
            this.TbEditEmail.ShortcutsEnabled = false;
            this.TbEditEmail.Size = new System.Drawing.Size(100, 22);
            this.TbEditEmail.TabIndex = 27;
            this.TbEditEmail.Visible = false;
            this.TbEditEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditEmail_KeyPress);
            // 
            // TbEditPhone
            // 
            this.TbEditPhone.Location = new System.Drawing.Point(430, 502);
            this.TbEditPhone.MaxLength = 15;
            this.TbEditPhone.Name = "TbEditPhone";
            this.TbEditPhone.ShortcutsEnabled = false;
            this.TbEditPhone.Size = new System.Drawing.Size(100, 22);
            this.TbEditPhone.TabIndex = 26;
            this.TbEditPhone.Visible = false;
            this.TbEditPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditPhone_KeyPress);
            // 
            // TbEditZipcode
            // 
            this.TbEditZipcode.Location = new System.Drawing.Point(430, 474);
            this.TbEditZipcode.MaxLength = 50;
            this.TbEditZipcode.Name = "TbEditZipcode";
            this.TbEditZipcode.ShortcutsEnabled = false;
            this.TbEditZipcode.Size = new System.Drawing.Size(100, 22);
            this.TbEditZipcode.TabIndex = 25;
            this.TbEditZipcode.Visible = false;
            this.TbEditZipcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditZipcode_KeyPress);
            // 
            // TbEditAdrress
            // 
            this.TbEditAdrress.Location = new System.Drawing.Point(430, 446);
            this.TbEditAdrress.MaxLength = 200;
            this.TbEditAdrress.Name = "TbEditAdrress";
            this.TbEditAdrress.ShortcutsEnabled = false;
            this.TbEditAdrress.Size = new System.Drawing.Size(100, 22);
            this.TbEditAdrress.TabIndex = 24;
            this.TbEditAdrress.Visible = false;
            this.TbEditAdrress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditAddress_KeyPress);
            // 
            // TbEditAge
            // 
            this.TbEditAge.Location = new System.Drawing.Point(430, 418);
            this.TbEditAge.MaxLength = 100;
            this.TbEditAge.Name = "TbEditAge";
            this.TbEditAge.ShortcutsEnabled = false;
            this.TbEditAge.Size = new System.Drawing.Size(100, 22);
            this.TbEditAge.TabIndex = 23;
            this.TbEditAge.Visible = false;
            this.TbEditAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditAge_KeyPress);
            // 
            // TbEditName
            // 
            this.TbEditName.Location = new System.Drawing.Point(430, 390);
            this.TbEditName.MaxLength = 100;
            this.TbEditName.Name = "TbEditName";
            this.TbEditName.ShortcutsEnabled = false;
            this.TbEditName.Size = new System.Drawing.Size(100, 22);
            this.TbEditName.TabIndex = 22;
            this.TbEditName.Visible = false;
            this.TbEditName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditName_KeyPress);
            // 
            // TbEditPassword
            // 
            this.TbEditPassword.Location = new System.Drawing.Point(430, 362);
            this.TbEditPassword.MaxLength = 100;
            this.TbEditPassword.Name = "TbEditPassword";
            this.TbEditPassword.ShortcutsEnabled = false;
            this.TbEditPassword.Size = new System.Drawing.Size(100, 22);
            this.TbEditPassword.TabIndex = 21;
            this.TbEditPassword.Visible = false;
            this.TbEditPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditPassword_KeyPress);
            // 
            // TbEditUsername
            // 
            this.TbEditUsername.Location = new System.Drawing.Point(430, 334);
            this.TbEditUsername.MaxLength = 100;
            this.TbEditUsername.Name = "TbEditUsername";
            this.TbEditUsername.ShortcutsEnabled = false;
            this.TbEditUsername.Size = new System.Drawing.Size(100, 22);
            this.TbEditUsername.TabIndex = 20;
            this.TbEditUsername.Visible = false;
            this.TbEditUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditUsername_KeyPress);
            // 
            // BtnEdit
            // 
            this.BtnEdit.Location = new System.Drawing.Point(430, 301);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(75, 23);
            this.BtnEdit.TabIndex = 19;
            this.BtnEdit.Text = "Edit";
            this.BtnEdit.UseVisualStyleBackColor = true;
            this.BtnEdit.Visible = false;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // TbEditId
            // 
            this.TbEditId.Enabled = false;
            this.TbEditId.Location = new System.Drawing.Point(430, 558);
            this.TbEditId.MaxLength = 11;
            this.TbEditId.Name = "TbEditId";
            this.TbEditId.ShortcutsEnabled = false;
            this.TbEditId.Size = new System.Drawing.Size(100, 22);
            this.TbEditId.TabIndex = 36;
            this.TbEditId.Visible = false;
            // 
            // LblEditId
            // 
            this.LblEditId.AutoSize = true;
            this.LblEditId.Location = new System.Drawing.Point(355, 558);
            this.LblEditId.Name = "LblEditId";
            this.LblEditId.Size = new System.Drawing.Size(19, 17);
            this.LblEditId.TabIndex = 37;
            this.LblEditId.Text = "id";
            this.LblEditId.Visible = false;
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(597, 301);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 23);
            this.BtnDelete.TabIndex = 38;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Visible = false;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // TbDelete
            // 
            this.TbDelete.Enabled = false;
            this.TbDelete.Location = new System.Drawing.Point(597, 334);
            this.TbDelete.MaxLength = 11;
            this.TbDelete.Name = "TbDelete";
            this.TbDelete.ShortcutsEnabled = false;
            this.TbDelete.Size = new System.Drawing.Size(100, 22);
            this.TbDelete.TabIndex = 39;
            this.TbDelete.Visible = false;
            // 
            // LblDelete
            // 
            this.LblDelete.AutoSize = true;
            this.LblDelete.Location = new System.Drawing.Point(572, 339);
            this.LblDelete.Name = "LblDelete";
            this.LblDelete.Size = new System.Drawing.Size(19, 17);
            this.LblDelete.TabIndex = 40;
            this.LblDelete.Text = "id";
            this.LblDelete.Visible = false;
            // 
            // BtnTimer
            // 
            this.BtnTimer.Location = new System.Drawing.Point(713, 302);
            this.BtnTimer.Name = "BtnTimer";
            this.BtnTimer.Size = new System.Drawing.Size(75, 23);
            this.BtnTimer.TabIndex = 41;
            this.BtnTimer.Text = "Timer";
            this.BtnTimer.UseVisualStyleBackColor = true;
            this.BtnTimer.Click += new System.EventHandler(this.BtnTimer_Click);
            // 
            // BtnLogout
            // 
            this.BtnLogout.Location = new System.Drawing.Point(713, 16);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(75, 23);
            this.BtnLogout.TabIndex = 42;
            this.BtnLogout.Text = "Logout";
            this.BtnLogout.UseVisualStyleBackColor = true;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // BtnUserItems
            // 
            this.BtnUserItems.Location = new System.Drawing.Point(703, 327);
            this.BtnUserItems.Name = "BtnUserItems";
            this.BtnUserItems.Size = new System.Drawing.Size(93, 23);
            this.BtnUserItems.TabIndex = 43;
            this.BtnUserItems.Text = "User_items";
            this.BtnUserItems.UseVisualStyleBackColor = true;
            this.BtnUserItems.Visible = false;
            this.BtnUserItems.Click += new System.EventHandler(this.BtnUserItems_Click);
            // 
            // BtnItems
            // 
            this.BtnItems.Location = new System.Drawing.Point(713, 357);
            this.BtnItems.Name = "BtnItems";
            this.BtnItems.Size = new System.Drawing.Size(75, 23);
            this.BtnItems.TabIndex = 44;
            this.BtnItems.Text = "Items";
            this.BtnItems.UseVisualStyleBackColor = true;
            this.BtnItems.Click += new System.EventHandler(this.BtnItems_Click);
            // 
            // Users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 585);
            this.Controls.Add(this.BtnItems);
            this.Controls.Add(this.BtnUserItems);
            this.Controls.Add(this.BtnLogout);
            this.Controls.Add(this.BtnTimer);
            this.Controls.Add(this.LblDelete);
            this.Controls.Add(this.TbDelete);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.LblEditId);
            this.Controls.Add(this.TbEditId);
            this.Controls.Add(this.LblEditEmail);
            this.Controls.Add(this.LblEditPhone);
            this.Controls.Add(this.LblEditZipcode);
            this.Controls.Add(this.LblEditAddress);
            this.Controls.Add(this.LblEditAge);
            this.Controls.Add(this.LblEditName);
            this.Controls.Add(this.LblEditPassword);
            this.Controls.Add(this.LblEditUsername);
            this.Controls.Add(this.TbEditEmail);
            this.Controls.Add(this.TbEditPhone);
            this.Controls.Add(this.TbEditZipcode);
            this.Controls.Add(this.TbEditAdrress);
            this.Controls.Add(this.TbEditAge);
            this.Controls.Add(this.TbEditName);
            this.Controls.Add(this.TbEditPassword);
            this.Controls.Add(this.TbEditUsername);
            this.Controls.Add(this.BtnEdit);
            this.Controls.Add(this.LblCreateEmail);
            this.Controls.Add(this.LblCreatePhone);
            this.Controls.Add(this.LblCreateZipcode);
            this.Controls.Add(this.LblCreateAddress);
            this.Controls.Add(this.LblCreateAge);
            this.Controls.Add(this.LblCreateName);
            this.Controls.Add(this.LblCreatePassword);
            this.Controls.Add(this.LblCreateUsername);
            this.Controls.Add(this.TbCreateEmail);
            this.Controls.Add(this.TbCreatePhone);
            this.Controls.Add(this.TbCreateZipcode);
            this.Controls.Add(this.TbCreateAddress);
            this.Controls.Add(this.TbCreateAge);
            this.Controls.Add(this.TbCreateName);
            this.Controls.Add(this.TbCreatePassword);
            this.Controls.Add(this.TbCreateUsername);
            this.Controls.Add(this.BtnCreate);
            this.Controls.Add(this.BtnShow);
            this.Controls.Add(this.DgvUsers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Users";
            this.Text = "Users";
            ((System.ComponentModel.ISupportInitialize)(this.DgvUsers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DgvUsers;
        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Button BtnCreate;
        private System.Windows.Forms.TextBox TbCreateUsername;
        private System.Windows.Forms.TextBox TbCreatePassword;
        private System.Windows.Forms.TextBox TbCreateName;
        private System.Windows.Forms.TextBox TbCreateAge;
        private System.Windows.Forms.TextBox TbCreateAddress;
        private System.Windows.Forms.TextBox TbCreateZipcode;
        private System.Windows.Forms.TextBox TbCreatePhone;
        private System.Windows.Forms.TextBox TbCreateEmail;
        private System.Windows.Forms.Label LblCreateUsername;
        private System.Windows.Forms.Label LblCreatePassword;
        private System.Windows.Forms.Label LblCreateName;
        private System.Windows.Forms.Label LblCreateAge;
        private System.Windows.Forms.Label LblCreateAddress;
        private System.Windows.Forms.Label LblCreateZipcode;
        private System.Windows.Forms.Label LblCreatePhone;
        private System.Windows.Forms.Label LblCreateEmail;
        private System.Windows.Forms.Label LblEditEmail;
        private System.Windows.Forms.Label LblEditPhone;
        private System.Windows.Forms.Label LblEditZipcode;
        private System.Windows.Forms.Label LblEditAddress;
        private System.Windows.Forms.Label LblEditAge;
        private System.Windows.Forms.Label LblEditName;
        private System.Windows.Forms.Label LblEditPassword;
        private System.Windows.Forms.Label LblEditUsername;
        private System.Windows.Forms.TextBox TbEditEmail;
        private System.Windows.Forms.TextBox TbEditPhone;
        private System.Windows.Forms.TextBox TbEditZipcode;
        private System.Windows.Forms.TextBox TbEditAdrress;
        private System.Windows.Forms.TextBox TbEditAge;
        private System.Windows.Forms.TextBox TbEditName;
        private System.Windows.Forms.TextBox TbEditPassword;
        private System.Windows.Forms.TextBox TbEditUsername;
        private System.Windows.Forms.Button BtnEdit;
        private System.Windows.Forms.TextBox TbEditId;
        private System.Windows.Forms.Label LblEditId;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.TextBox TbDelete;
        private System.Windows.Forms.Label LblDelete;
        private System.Windows.Forms.Button BtnTimer;
        private System.Windows.Forms.Button BtnLogout;
        private System.Windows.Forms.Button BtnUserItems;
        private System.Windows.Forms.Button BtnItems;
    }
}