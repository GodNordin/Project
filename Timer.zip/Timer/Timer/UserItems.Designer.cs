﻿namespace Timer
{
    partial class UserItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DgvUserItems = new System.Windows.Forms.DataGridView();
            this.BtnShow = new System.Windows.Forms.Button();
            this.BtnCreate = new System.Windows.Forms.Button();
            this.TbCreateUsers = new System.Windows.Forms.TextBox();
            this.TbCreateItems = new System.Windows.Forms.TextBox();
            this.LblCreateUsers = new System.Windows.Forms.Label();
            this.LblCreateItems = new System.Windows.Forms.Label();
            this.TbCreateAmount = new System.Windows.Forms.TextBox();
            this.LblCreateAmount = new System.Windows.Forms.Label();
            this.LblEditAmount = new System.Windows.Forms.Label();
            this.TbEditAmount = new System.Windows.Forms.TextBox();
            this.LblEditItems = new System.Windows.Forms.Label();
            this.LblDelete = new System.Windows.Forms.Label();
            this.TbEditItems = new System.Windows.Forms.TextBox();
            this.TbEditUsers = new System.Windows.Forms.TextBox();
            this.BtnEdit = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.TbDelete = new System.Windows.Forms.TextBox();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.BtnTimer = new System.Windows.Forms.Button();
            this.BtnUsers = new System.Windows.Forms.Button();
            this.LblEditUsers = new System.Windows.Forms.Label();
            this.TbCreateHours = new System.Windows.Forms.TextBox();
            this.LblCreateHours = new System.Windows.Forms.Label();
            this.LblEditHours = new System.Windows.Forms.Label();
            this.TbEditHours = new System.Windows.Forms.TextBox();
            this.BtnItems = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUserItems)).BeginInit();
            this.SuspendLayout();
            // 
            // DgvUserItems
            // 
            this.DgvUserItems.AllowUserToAddRows = false;
            this.DgvUserItems.AllowUserToDeleteRows = false;
            this.DgvUserItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvUserItems.Location = new System.Drawing.Point(13, 45);
            this.DgvUserItems.Name = "DgvUserItems";
            this.DgvUserItems.ReadOnly = true;
            this.DgvUserItems.RowTemplate.Height = 24;
            this.DgvUserItems.Size = new System.Drawing.Size(775, 211);
            this.DgvUserItems.TabIndex = 0;
            this.DgvUserItems.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvUserItems_CellClick);
            // 
            // BtnShow
            // 
            this.BtnShow.Location = new System.Drawing.Point(13, 263);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(75, 23);
            this.BtnShow.TabIndex = 1;
            this.BtnShow.Text = "Show";
            this.BtnShow.UseVisualStyleBackColor = true;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // BtnCreate
            // 
            this.BtnCreate.Location = new System.Drawing.Point(172, 262);
            this.BtnCreate.Name = "BtnCreate";
            this.BtnCreate.Size = new System.Drawing.Size(75, 23);
            this.BtnCreate.TabIndex = 2;
            this.BtnCreate.Text = "Create";
            this.BtnCreate.UseVisualStyleBackColor = true;
            this.BtnCreate.Visible = false;
            this.BtnCreate.Click += new System.EventHandler(this.BtnCreate_Click);
            // 
            // TbCreateUsers
            // 
            this.TbCreateUsers.Location = new System.Drawing.Point(172, 292);
            this.TbCreateUsers.MaxLength = 10;
            this.TbCreateUsers.Name = "TbCreateUsers";
            this.TbCreateUsers.ShortcutsEnabled = false;
            this.TbCreateUsers.Size = new System.Drawing.Size(100, 22);
            this.TbCreateUsers.TabIndex = 3;
            this.TbCreateUsers.Visible = false;
            this.TbCreateUsers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateUsers_KeyPress);
            // 
            // TbCreateItems
            // 
            this.TbCreateItems.Location = new System.Drawing.Point(172, 320);
            this.TbCreateItems.MaxLength = 10;
            this.TbCreateItems.Name = "TbCreateItems";
            this.TbCreateItems.ShortcutsEnabled = false;
            this.TbCreateItems.Size = new System.Drawing.Size(100, 22);
            this.TbCreateItems.TabIndex = 4;
            this.TbCreateItems.Visible = false;
            this.TbCreateItems.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateItems_KeyPress);
            // 
            // LblCreateUsers
            // 
            this.LblCreateUsers.AutoSize = true;
            this.LblCreateUsers.Location = new System.Drawing.Point(98, 297);
            this.LblCreateUsers.Name = "LblCreateUsers";
            this.LblCreateUsers.Size = new System.Drawing.Size(54, 17);
            this.LblCreateUsers.TabIndex = 5;
            this.LblCreateUsers.Text = "usersid";
            this.LblCreateUsers.Visible = false;
            // 
            // LblCreateItems
            // 
            this.LblCreateItems.AutoSize = true;
            this.LblCreateItems.Location = new System.Drawing.Point(98, 325);
            this.LblCreateItems.Name = "LblCreateItems";
            this.LblCreateItems.Size = new System.Drawing.Size(52, 17);
            this.LblCreateItems.TabIndex = 6;
            this.LblCreateItems.Text = "itemsid";
            this.LblCreateItems.Visible = false;
            // 
            // TbCreateAmount
            // 
            this.TbCreateAmount.Location = new System.Drawing.Point(172, 348);
            this.TbCreateAmount.MaxLength = 10;
            this.TbCreateAmount.Name = "TbCreateAmount";
            this.TbCreateAmount.ShortcutsEnabled = false;
            this.TbCreateAmount.Size = new System.Drawing.Size(100, 22);
            this.TbCreateAmount.TabIndex = 7;
            this.TbCreateAmount.Visible = false;
            this.TbCreateAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateAmount_KeyPress);
            // 
            // LblCreateAmount
            // 
            this.LblCreateAmount.AutoSize = true;
            this.LblCreateAmount.Location = new System.Drawing.Point(98, 351);
            this.LblCreateAmount.Name = "LblCreateAmount";
            this.LblCreateAmount.Size = new System.Drawing.Size(66, 17);
            this.LblCreateAmount.TabIndex = 8;
            this.LblCreateAmount.Text = "amountid";
            this.LblCreateAmount.Visible = false;
            // 
            // LblEditAmount
            // 
            this.LblEditAmount.AutoSize = true;
            this.LblEditAmount.Location = new System.Drawing.Point(306, 351);
            this.LblEditAmount.Name = "LblEditAmount";
            this.LblEditAmount.Size = new System.Drawing.Size(66, 17);
            this.LblEditAmount.TabIndex = 15;
            this.LblEditAmount.Text = "amountid";
            this.LblEditAmount.Visible = false;
            // 
            // TbEditAmount
            // 
            this.TbEditAmount.Location = new System.Drawing.Point(380, 348);
            this.TbEditAmount.MaxLength = 10;
            this.TbEditAmount.Name = "TbEditAmount";
            this.TbEditAmount.ShortcutsEnabled = false;
            this.TbEditAmount.Size = new System.Drawing.Size(100, 22);
            this.TbEditAmount.TabIndex = 14;
            this.TbEditAmount.Visible = false;
            this.TbEditAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditAmount_KeyPress);
            // 
            // LblEditItems
            // 
            this.LblEditItems.AutoSize = true;
            this.LblEditItems.Location = new System.Drawing.Point(306, 325);
            this.LblEditItems.Name = "LblEditItems";
            this.LblEditItems.Size = new System.Drawing.Size(52, 17);
            this.LblEditItems.TabIndex = 13;
            this.LblEditItems.Text = "itemsid";
            this.LblEditItems.Visible = false;
            // 
            // LblDelete
            // 
            this.LblDelete.AutoSize = true;
            this.LblDelete.Location = new System.Drawing.Point(510, 297);
            this.LblDelete.Name = "LblDelete";
            this.LblDelete.Size = new System.Drawing.Size(54, 17);
            this.LblDelete.TabIndex = 12;
            this.LblDelete.Text = "usersid";
            this.LblDelete.Visible = false;
            // 
            // TbEditItems
            // 
            this.TbEditItems.Location = new System.Drawing.Point(380, 320);
            this.TbEditItems.MaxLength = 10;
            this.TbEditItems.Name = "TbEditItems";
            this.TbEditItems.ShortcutsEnabled = false;
            this.TbEditItems.Size = new System.Drawing.Size(100, 22);
            this.TbEditItems.TabIndex = 11;
            this.TbEditItems.Visible = false;
            this.TbEditItems.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditItems_KeyPress);
            // 
            // TbEditUsers
            // 
            this.TbEditUsers.Location = new System.Drawing.Point(380, 292);
            this.TbEditUsers.MaxLength = 10;
            this.TbEditUsers.Name = "TbEditUsers";
            this.TbEditUsers.ShortcutsEnabled = false;
            this.TbEditUsers.Size = new System.Drawing.Size(100, 22);
            this.TbEditUsers.TabIndex = 10;
            this.TbEditUsers.Visible = false;
            this.TbEditUsers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditUsers_KeyPress);
            // 
            // BtnEdit
            // 
            this.BtnEdit.Location = new System.Drawing.Point(380, 262);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(75, 23);
            this.BtnEdit.TabIndex = 9;
            this.BtnEdit.Text = "Edit";
            this.BtnEdit.UseVisualStyleBackColor = true;
            this.BtnEdit.Visible = false;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(570, 262);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 23);
            this.BtnDelete.TabIndex = 16;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Visible = false;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // TbDelete
            // 
            this.TbDelete.Enabled = false;
            this.TbDelete.Location = new System.Drawing.Point(570, 292);
            this.TbDelete.MaxLength = 10;
            this.TbDelete.Name = "TbDelete";
            this.TbDelete.ShortcutsEnabled = false;
            this.TbDelete.Size = new System.Drawing.Size(100, 22);
            this.TbDelete.TabIndex = 17;
            this.TbDelete.Visible = false;
            // 
            // BtnLogout
            // 
            this.BtnLogout.Location = new System.Drawing.Point(704, 13);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(75, 23);
            this.BtnLogout.TabIndex = 18;
            this.BtnLogout.Text = "Logout";
            this.BtnLogout.UseVisualStyleBackColor = true;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // BtnTimer
            // 
            this.BtnTimer.Location = new System.Drawing.Point(713, 263);
            this.BtnTimer.Name = "BtnTimer";
            this.BtnTimer.Size = new System.Drawing.Size(75, 23);
            this.BtnTimer.TabIndex = 19;
            this.BtnTimer.Text = "Timer";
            this.BtnTimer.UseVisualStyleBackColor = true;
            this.BtnTimer.Click += new System.EventHandler(this.BtnTimer_Click);
            // 
            // BtnUsers
            // 
            this.BtnUsers.Location = new System.Drawing.Point(713, 291);
            this.BtnUsers.Name = "BtnUsers";
            this.BtnUsers.Size = new System.Drawing.Size(75, 23);
            this.BtnUsers.TabIndex = 20;
            this.BtnUsers.Text = "Users";
            this.BtnUsers.UseVisualStyleBackColor = true;
            this.BtnUsers.Click += new System.EventHandler(this.BtnUsers_Click);
            // 
            // LblEditUsers
            // 
            this.LblEditUsers.AutoSize = true;
            this.LblEditUsers.Location = new System.Drawing.Point(306, 292);
            this.LblEditUsers.Name = "LblEditUsers";
            this.LblEditUsers.Size = new System.Drawing.Size(54, 17);
            this.LblEditUsers.TabIndex = 21;
            this.LblEditUsers.Text = "usersid";
            this.LblEditUsers.Visible = false;
            // 
            // TbCreateHours
            // 
            this.TbCreateHours.Location = new System.Drawing.Point(172, 376);
            this.TbCreateHours.MaxLength = 10;
            this.TbCreateHours.Name = "TbCreateHours";
            this.TbCreateHours.ShortcutsEnabled = false;
            this.TbCreateHours.Size = new System.Drawing.Size(100, 22);
            this.TbCreateHours.TabIndex = 22;
            this.TbCreateHours.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateHours_KeyPress);
            // 
            // LblCreateHours
            // 
            this.LblCreateHours.AutoSize = true;
            this.LblCreateHours.Location = new System.Drawing.Point(98, 381);
            this.LblCreateHours.Name = "LblCreateHours";
            this.LblCreateHours.Size = new System.Drawing.Size(55, 17);
            this.LblCreateHours.TabIndex = 23;
            this.LblCreateHours.Text = "hoursid";
            // 
            // LblEditHours
            // 
            this.LblEditHours.AutoSize = true;
            this.LblEditHours.Location = new System.Drawing.Point(306, 383);
            this.LblEditHours.Name = "LblEditHours";
            this.LblEditHours.Size = new System.Drawing.Size(55, 17);
            this.LblEditHours.TabIndex = 25;
            this.LblEditHours.Text = "hoursid";
            // 
            // TbEditHours
            // 
            this.TbEditHours.Location = new System.Drawing.Point(380, 378);
            this.TbEditHours.MaxLength = 10;
            this.TbEditHours.Name = "TbEditHours";
            this.TbEditHours.ShortcutsEnabled = false;
            this.TbEditHours.Size = new System.Drawing.Size(100, 22);
            this.TbEditHours.TabIndex = 24;
            this.TbEditHours.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditHours_KeyPress);
            // 
            // BtnItems
            // 
            this.BtnItems.Location = new System.Drawing.Point(713, 320);
            this.BtnItems.Name = "BtnItems";
            this.BtnItems.Size = new System.Drawing.Size(75, 23);
            this.BtnItems.TabIndex = 26;
            this.BtnItems.Text = "items";
            this.BtnItems.UseVisualStyleBackColor = true;
            this.BtnItems.Click += new System.EventHandler(this.BtnItems_Click);
            // 
            // UserItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnItems);
            this.Controls.Add(this.LblEditHours);
            this.Controls.Add(this.TbEditHours);
            this.Controls.Add(this.LblCreateHours);
            this.Controls.Add(this.TbCreateHours);
            this.Controls.Add(this.LblEditUsers);
            this.Controls.Add(this.BtnUsers);
            this.Controls.Add(this.BtnTimer);
            this.Controls.Add(this.BtnLogout);
            this.Controls.Add(this.TbDelete);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.LblEditAmount);
            this.Controls.Add(this.TbEditAmount);
            this.Controls.Add(this.LblEditItems);
            this.Controls.Add(this.LblDelete);
            this.Controls.Add(this.TbEditItems);
            this.Controls.Add(this.TbEditUsers);
            this.Controls.Add(this.BtnEdit);
            this.Controls.Add(this.LblCreateAmount);
            this.Controls.Add(this.TbCreateAmount);
            this.Controls.Add(this.LblCreateItems);
            this.Controls.Add(this.LblCreateUsers);
            this.Controls.Add(this.TbCreateItems);
            this.Controls.Add(this.TbCreateUsers);
            this.Controls.Add(this.BtnCreate);
            this.Controls.Add(this.BtnShow);
            this.Controls.Add(this.DgvUserItems);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UserItems";
            this.Text = "UserItems";
            ((System.ComponentModel.ISupportInitialize)(this.DgvUserItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DgvUserItems;
        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Button BtnCreate;
        private System.Windows.Forms.TextBox TbCreateUsers;
        private System.Windows.Forms.TextBox TbCreateItems;
        private System.Windows.Forms.Label LblCreateUsers;
        private System.Windows.Forms.Label LblCreateItems;
        private System.Windows.Forms.TextBox TbCreateAmount;
        private System.Windows.Forms.Label LblCreateAmount;
        private System.Windows.Forms.Label LblEditAmount;
        private System.Windows.Forms.TextBox TbEditAmount;
        private System.Windows.Forms.Label LblEditItems;
        private System.Windows.Forms.Label LblDelete;
        private System.Windows.Forms.TextBox TbEditItems;
        private System.Windows.Forms.TextBox TbEditUsers;
        private System.Windows.Forms.Button BtnEdit;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.TextBox TbDelete;
        private System.Windows.Forms.Button BtnLogout;
        private System.Windows.Forms.Button BtnTimer;
        private System.Windows.Forms.Button BtnUsers;
        private System.Windows.Forms.Label LblEditUsers;
        private System.Windows.Forms.TextBox TbCreateHours;
        private System.Windows.Forms.Label LblCreateHours;
        private System.Windows.Forms.Label LblEditHours;
        private System.Windows.Forms.TextBox TbEditHours;
        private System.Windows.Forms.Button BtnItems;
    }
}