﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Timer
{
    public partial class Users : Form
    {
        Mysqlquery mysqlquery = new Mysqlquery();

        public Users()
        {
            InitializeComponent();
            DgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DgvUsers.MultiSelect = false;
            if (Admin.admin == 1)
            {
                TbCreateUsername.Visible = true;
                TbCreatePassword.Visible = true;
                TbCreateName.Visible = true;
                TbCreateAge.Visible = true;
                TbCreateAddress.Visible = true;
                TbCreateZipcode.Visible = true;
                TbCreatePhone.Visible = true;
                TbCreateEmail.Visible = true;
                TbEditEmail.Visible = true;
                TbEditPhone.Visible = true;
                TbEditZipcode.Visible = true;
                TbEditAdrress.Visible = true;
                TbEditAge.Visible = true;
                TbEditName.Visible = true;
                TbEditPassword.Visible = true;
                TbEditUsername.Visible = true;
                TbEditId.Visible = true;
                TbDelete.Visible = true;
                BtnCreate.Visible = true;
                BtnEdit.Visible = true;
                BtnShow.Visible = true;
                BtnUserItems.Visible = true;
                BtnDelete.Visible = true;
                LblCreateUsername.Visible = true;
                LblCreatePassword.Visible = true;
                LblCreateName.Visible = true;
                LblCreateAge.Visible = true;
                LblCreateAddress.Visible = true;
                LblCreateZipcode.Visible = true;
                LblCreatePhone.Visible = true;
                LblCreateEmail.Visible = true;
                LblEditEmail.Visible = true;
                LblEditPhone.Visible = true;
                LblEditZipcode.Visible = true;
                LblEditAddress.Visible = true;
                LblEditAge.Visible = true;
                LblEditName.Visible = true;
                LblEditPassword.Visible = true;
                LblEditUsername.Visible = true;
                LblEditId.Visible = true;
                LblDelete.Visible = true;
                DgvUsers.Visible = true;
            }
            else
            {
                MySqlDataReader sdr = mysqlquery.Reader("SELECT * FROM users WHERE id=@id", "@id", Admin.userid);
                if(sdr.Read())
                {
                    TbCreateUsername.Text = sdr.GetString(1);
                    TbCreateName.Text = sdr.GetString(3);
                    TbCreateAge.Text = sdr.GetInt32(4).ToString();
                    TbCreateAddress.Text = sdr.GetString(5);
                    TbCreateZipcode.Text = sdr.GetString(6);
                    TbCreatePhone.Text = sdr.GetString(7);
                    TbCreateEmail.Text = sdr.GetString(8);
                }
                this.Size = new Size(300, 280);
                LblCreateUsername.Location = new Point(12, 10);
                TbCreateUsername.Location = new Point(70, 10);
                LblCreatePassword.Location = new Point(12, 35);
                TbCreatePassword.Location = new Point(70, 35);
                LblCreateName.Location = new Point(12, 60);
                TbCreateName.Location = new Point(70, 60);
                LblCreateAge.Location = new Point(12, 85);
                TbCreateAge.Location = new Point(70, 85);
                LblCreateAddress.Location = new Point(12, 110);
                TbCreateAddress.Location = new Point(70, 110);
                LblCreateZipcode.Location = new Point(12, 135);
                TbCreateZipcode.Location = new Point(70, 135);
                LblCreatePhone.Location = new Point(12, 160);
                TbCreatePhone.Location = new Point(70, 160);
                LblCreateEmail.Location = new Point(12, 185);
                TbCreateEmail.Location = new Point(70, 185);
                BtnLogout.Location = new Point(200, 10);
                BtnTimer.Location = new Point(200, 50);
            }
        }

        private new void Show()
        {
            DgvUsers.DataSource = mysqlquery.Data("SELECT * FROM users");
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            Show();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.CreateUsers("INSERT INTO users(username, `password`, name, age, address, zipcode, phone, email, admin) VALUES (@username, @password, @name, @age, @address, @zipcode, @phone, @email, 0)", "@username", TbCreateUsername.Text, "@password", Helper.Encrypt(TbCreatePassword.Text), "@name", TbCreateName.Text, "@age", Convert.ToInt32(TbCreateAge.Text), "@address", TbCreateAddress.Text, "@zipcode", TbCreateZipcode.Text, "@phone", Convert.ToInt32(TbCreatePhone.Text), "@email", TbCreateEmail.Text);
                MessageBox.Show("Recored successfully created");
                Show();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + " fill in all textboxs");
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.EditUsers("UPDATE users SET username=@username, `password`=@password, name=@name, age=@age, address=@address, zipcode=@zipcode, phone=@phone, email=@email, admin=0 WHERE id=@id", "@username", TbEditUsername.Text, "@password", Helper.Encrypt(TbEditPassword.Text), "@name", TbEditName.Text, "@age", Convert.ToInt32(TbEditAge.Text), "@address", TbEditAdrress.Text, "@zipcode", TbEditZipcode.Text, "@phone", Convert.ToInt32(TbEditPhone.Text), "@email", TbEditEmail.Text, "@id", Convert.ToInt32(TbEditId.Text));
                MessageBox.Show("Record Edited Successfully");
                Show();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + " fill in all textboxs");
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                mysqlquery.Delete("DELETE FROM users WHERE id = @id", "@id", Convert.ToInt32(TbDelete.Text));
                MessageBox.Show("Record deleted Successfully");
                Show();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + " fill in all textboxs");
            }
        }

        private void BtnTimer_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Hide();
        }

        private void BtnUserItems_Click(object sender, EventArgs e)
        {
            UserItems userItems = new UserItems();
            userItems.Show();
            Hide();
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            Hide();
        }

        private void DgvUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = DgvUsers.Rows[index];
            TbEditUsername.Text = selectedRow.Cells[1].Value.ToString();
            TbEditName.Text = selectedRow.Cells[3].Value.ToString();
            TbEditAge.Text = selectedRow.Cells[4].Value.ToString();
            TbEditAdrress.Text = selectedRow.Cells[5].Value.ToString();
            TbEditZipcode.Text = selectedRow.Cells[6].Value.ToString();
            TbEditPhone.Text = selectedRow.Cells[7].Value.ToString();
            TbEditEmail.Text = selectedRow.Cells[8].Value.ToString();
            TbEditId.Text = selectedRow.Cells[0].Value.ToString();
            TbDelete.Text = selectedRow.Cells[0].Value.ToString();
        }

        private void TbEditUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditName_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
(e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void TbEditAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditZipcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbEditPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
(e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void TbEditEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void TbCreateEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreatePhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
(e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void TbCreateZipcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreateAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreateAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
(e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void TbCreateName_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreatePassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void TbCreateUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s\b]");
            if (regex.IsMatch(e.KeyChar.ToString()))
            {
                e.Handled = true;
            }
        }

        private void BtnItems_Click(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Hide();
        }
    }
}