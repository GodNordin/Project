﻿namespace Timer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnShow = new System.Windows.Forms.Button();
            this.BtnUsers = new System.Windows.Forms.Button();
            this.TbUser = new System.Windows.Forms.TextBox();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.BtnUserItems = new System.Windows.Forms.Button();
            this.LblUser = new System.Windows.Forms.Label();
            this.BtnItems = new System.Windows.Forms.Button();
            this.DgvItems = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DgvItems)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnShow
            // 
            this.BtnShow.Location = new System.Drawing.Point(64, 214);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(75, 23);
            this.BtnShow.TabIndex = 3;
            this.BtnShow.Text = "Show";
            this.BtnShow.UseVisualStyleBackColor = true;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // BtnUsers
            // 
            this.BtnUsers.Location = new System.Drawing.Point(925, 214);
            this.BtnUsers.Name = "BtnUsers";
            this.BtnUsers.Size = new System.Drawing.Size(75, 23);
            this.BtnUsers.TabIndex = 21;
            this.BtnUsers.Text = "Users";
            this.BtnUsers.UseVisualStyleBackColor = true;
            this.BtnUsers.Click += new System.EventHandler(this.BtnUsers_Click);
            // 
            // TbUser
            // 
            this.TbUser.Enabled = false;
            this.TbUser.Location = new System.Drawing.Point(64, 12);
            this.TbUser.Name = "TbUser";
            this.TbUser.Size = new System.Drawing.Size(100, 22);
            this.TbUser.TabIndex = 22;
            // 
            // BtnLogout
            // 
            this.BtnLogout.Location = new System.Drawing.Point(925, 9);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(75, 23);
            this.BtnLogout.TabIndex = 23;
            this.BtnLogout.Text = "Logout";
            this.BtnLogout.UseVisualStyleBackColor = true;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // BtnUserItems
            // 
            this.BtnUserItems.Location = new System.Drawing.Point(910, 243);
            this.BtnUserItems.Name = "BtnUserItems";
            this.BtnUserItems.Size = new System.Drawing.Size(90, 23);
            this.BtnUserItems.TabIndex = 32;
            this.BtnUserItems.Text = "User items";
            this.BtnUserItems.UseVisualStyleBackColor = true;
            this.BtnUserItems.Visible = false;
            this.BtnUserItems.Click += new System.EventHandler(this.BtnUserItems_Click);
            // 
            // LblUser
            // 
            this.LblUser.AutoSize = true;
            this.LblUser.Location = new System.Drawing.Point(6, 15);
            this.LblUser.Name = "LblUser";
            this.LblUser.Size = new System.Drawing.Size(38, 17);
            this.LblUser.TabIndex = 33;
            this.LblUser.Text = "User";
            // 
            // BtnItems
            // 
            this.BtnItems.Location = new System.Drawing.Point(925, 283);
            this.BtnItems.Name = "BtnItems";
            this.BtnItems.Size = new System.Drawing.Size(75, 23);
            this.BtnItems.TabIndex = 34;
            this.BtnItems.Text = "items";
            this.BtnItems.UseVisualStyleBackColor = true;
            this.BtnItems.Visible = false;
            this.BtnItems.Click += new System.EventHandler(this.BtnItems_Click);
            // 
            // DgvItems
            // 
            this.DgvItems.AllowUserToAddRows = false;
            this.DgvItems.AllowUserToDeleteRows = false;
            this.DgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvItems.Location = new System.Drawing.Point(64, 41);
            this.DgvItems.Name = "DgvItems";
            this.DgvItems.ReadOnly = true;
            this.DgvItems.RowTemplate.Height = 24;
            this.DgvItems.Size = new System.Drawing.Size(936, 150);
            this.DgvItems.TabIndex = 35;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1012, 323);
            this.Controls.Add(this.DgvItems);
            this.Controls.Add(this.BtnItems);
            this.Controls.Add(this.LblUser);
            this.Controls.Add(this.BtnUserItems);
            this.Controls.Add(this.BtnLogout);
            this.Controls.Add(this.TbUser);
            this.Controls.Add(this.BtnUsers);
            this.Controls.Add(this.BtnShow);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DgvItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Button BtnUsers;
        private System.Windows.Forms.TextBox TbUser;
        private System.Windows.Forms.Button BtnLogout;
        private System.Windows.Forms.Button BtnUserItems;
        private System.Windows.Forms.Label LblUser;
        private System.Windows.Forms.Button BtnItems;
        private System.Windows.Forms.DataGridView DgvItems;
    }
}

