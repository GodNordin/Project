﻿namespace Timer
{
    partial class Items
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DgvItems = new System.Windows.Forms.DataGridView();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.BtnTimer = new System.Windows.Forms.Button();
            this.BtnUserItems = new System.Windows.Forms.Button();
            this.BtnUsers = new System.Windows.Forms.Button();
            this.BtnShow = new System.Windows.Forms.Button();
            this.BtnCreate = new System.Windows.Forms.Button();
            this.BtnEdit = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.TbCreateAmount = new System.Windows.Forms.TextBox();
            this.TbCreateName = new System.Windows.Forms.TextBox();
            this.TbEditAmount = new System.Windows.Forms.TextBox();
            this.TbEditName = new System.Windows.Forms.TextBox();
            this.TbDelete = new System.Windows.Forms.TextBox();
            this.LblCreateAmount = new System.Windows.Forms.Label();
            this.LblCreateName = new System.Windows.Forms.Label();
            this.LblEditAmount = new System.Windows.Forms.Label();
            this.LblEditName = new System.Windows.Forms.Label();
            this.LblDelete = new System.Windows.Forms.Label();
            this.TbEditId = new System.Windows.Forms.TextBox();
            this.LblEditId = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DgvItems)).BeginInit();
            this.SuspendLayout();
            // 
            // DgvItems
            // 
            this.DgvItems.AllowUserToAddRows = false;
            this.DgvItems.AllowUserToDeleteRows = false;
            this.DgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvItems.Location = new System.Drawing.Point(27, 51);
            this.DgvItems.Name = "DgvItems";
            this.DgvItems.ReadOnly = true;
            this.DgvItems.RowTemplate.Height = 24;
            this.DgvItems.Size = new System.Drawing.Size(737, 203);
            this.DgvItems.TabIndex = 0;
            this.DgvItems.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvItems_CellClick);
            // 
            // BtnLogout
            // 
            this.BtnLogout.Location = new System.Drawing.Point(689, 12);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(75, 23);
            this.BtnLogout.TabIndex = 1;
            this.BtnLogout.Text = "Logout";
            this.BtnLogout.UseVisualStyleBackColor = true;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // BtnTimer
            // 
            this.BtnTimer.Location = new System.Drawing.Point(689, 261);
            this.BtnTimer.Name = "BtnTimer";
            this.BtnTimer.Size = new System.Drawing.Size(75, 23);
            this.BtnTimer.TabIndex = 2;
            this.BtnTimer.Text = "Timer";
            this.BtnTimer.UseVisualStyleBackColor = true;
            this.BtnTimer.Click += new System.EventHandler(this.BtnTimer_Click);
            // 
            // BtnUserItems
            // 
            this.BtnUserItems.Location = new System.Drawing.Point(683, 291);
            this.BtnUserItems.Name = "BtnUserItems";
            this.BtnUserItems.Size = new System.Drawing.Size(81, 23);
            this.BtnUserItems.TabIndex = 3;
            this.BtnUserItems.Text = "UserItems";
            this.BtnUserItems.UseVisualStyleBackColor = true;
            this.BtnUserItems.Click += new System.EventHandler(this.BtnUserItems_Click);
            // 
            // BtnUsers
            // 
            this.BtnUsers.Location = new System.Drawing.Point(689, 321);
            this.BtnUsers.Name = "BtnUsers";
            this.BtnUsers.Size = new System.Drawing.Size(75, 23);
            this.BtnUsers.TabIndex = 4;
            this.BtnUsers.Text = "Users";
            this.BtnUsers.UseVisualStyleBackColor = true;
            this.BtnUsers.Click += new System.EventHandler(this.BtnUsers_Click);
            // 
            // BtnShow
            // 
            this.BtnShow.Location = new System.Drawing.Point(27, 260);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(75, 23);
            this.BtnShow.TabIndex = 5;
            this.BtnShow.Text = "Show";
            this.BtnShow.UseVisualStyleBackColor = true;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // BtnCreate
            // 
            this.BtnCreate.Location = new System.Drawing.Point(171, 260);
            this.BtnCreate.Name = "BtnCreate";
            this.BtnCreate.Size = new System.Drawing.Size(75, 23);
            this.BtnCreate.TabIndex = 6;
            this.BtnCreate.Text = "Create";
            this.BtnCreate.UseVisualStyleBackColor = true;
            this.BtnCreate.Click += new System.EventHandler(this.BtnCreate_Click);
            // 
            // BtnEdit
            // 
            this.BtnEdit.Location = new System.Drawing.Point(354, 260);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(75, 23);
            this.BtnEdit.TabIndex = 7;
            this.BtnEdit.Text = "Edit";
            this.BtnEdit.UseVisualStyleBackColor = true;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(541, 261);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 23);
            this.BtnDelete.TabIndex = 8;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // TbCreateAmount
            // 
            this.TbCreateAmount.Location = new System.Drawing.Point(171, 303);
            this.TbCreateAmount.MaxLength = 8;
            this.TbCreateAmount.Name = "TbCreateAmount";
            this.TbCreateAmount.ShortcutsEnabled = false;
            this.TbCreateAmount.Size = new System.Drawing.Size(100, 22);
            this.TbCreateAmount.TabIndex = 9;
            this.TbCreateAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateAmount_KeyPress);
            // 
            // TbCreateName
            // 
            this.TbCreateName.Location = new System.Drawing.Point(171, 332);
            this.TbCreateName.MaxLength = 100;
            this.TbCreateName.Name = "TbCreateName";
            this.TbCreateName.ShortcutsEnabled = false;
            this.TbCreateName.Size = new System.Drawing.Size(100, 22);
            this.TbCreateName.TabIndex = 10;
            this.TbCreateName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbCreateName_KeyPress);
            // 
            // TbEditAmount
            // 
            this.TbEditAmount.Location = new System.Drawing.Point(354, 303);
            this.TbEditAmount.MaxLength = 8;
            this.TbEditAmount.Name = "TbEditAmount";
            this.TbEditAmount.ShortcutsEnabled = false;
            this.TbEditAmount.Size = new System.Drawing.Size(100, 22);
            this.TbEditAmount.TabIndex = 11;
            this.TbEditAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditAmount_KeyPress);
            // 
            // TbEditName
            // 
            this.TbEditName.Location = new System.Drawing.Point(354, 332);
            this.TbEditName.MaxLength = 100;
            this.TbEditName.Name = "TbEditName";
            this.TbEditName.ShortcutsEnabled = false;
            this.TbEditName.Size = new System.Drawing.Size(100, 22);
            this.TbEditName.TabIndex = 12;
            this.TbEditName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TbEditName_KeyPress);
            // 
            // TbDelete
            // 
            this.TbDelete.Enabled = false;
            this.TbDelete.Location = new System.Drawing.Point(541, 302);
            this.TbDelete.Name = "TbDelete";
            this.TbDelete.Size = new System.Drawing.Size(100, 22);
            this.TbDelete.TabIndex = 13;
            // 
            // LblCreateAmount
            // 
            this.LblCreateAmount.AutoSize = true;
            this.LblCreateAmount.Location = new System.Drawing.Point(109, 305);
            this.LblCreateAmount.Name = "LblCreateAmount";
            this.LblCreateAmount.Size = new System.Drawing.Size(56, 17);
            this.LblCreateAmount.TabIndex = 14;
            this.LblCreateAmount.Text = "Amount";
            // 
            // LblCreateName
            // 
            this.LblCreateName.AutoSize = true;
            this.LblCreateName.Location = new System.Drawing.Point(112, 336);
            this.LblCreateName.Name = "LblCreateName";
            this.LblCreateName.Size = new System.Drawing.Size(45, 17);
            this.LblCreateName.TabIndex = 15;
            this.LblCreateName.Text = "Name";
            // 
            // LblEditAmount
            // 
            this.LblEditAmount.AutoSize = true;
            this.LblEditAmount.Location = new System.Drawing.Point(297, 305);
            this.LblEditAmount.Name = "LblEditAmount";
            this.LblEditAmount.Size = new System.Drawing.Size(56, 17);
            this.LblEditAmount.TabIndex = 16;
            this.LblEditAmount.Text = "Amount";
            // 
            // LblEditName
            // 
            this.LblEditName.AutoSize = true;
            this.LblEditName.Location = new System.Drawing.Point(300, 332);
            this.LblEditName.Name = "LblEditName";
            this.LblEditName.Size = new System.Drawing.Size(45, 17);
            this.LblEditName.TabIndex = 17;
            this.LblEditName.Text = "Name";
            // 
            // LblDelete
            // 
            this.LblDelete.AutoSize = true;
            this.LblDelete.Location = new System.Drawing.Point(516, 305);
            this.LblDelete.Name = "LblDelete";
            this.LblDelete.Size = new System.Drawing.Size(19, 17);
            this.LblDelete.TabIndex = 18;
            this.LblDelete.Text = "id";
            // 
            // TbEditId
            // 
            this.TbEditId.Enabled = false;
            this.TbEditId.Location = new System.Drawing.Point(354, 361);
            this.TbEditId.Name = "TbEditId";
            this.TbEditId.ShortcutsEnabled = false;
            this.TbEditId.Size = new System.Drawing.Size(100, 22);
            this.TbEditId.TabIndex = 19;
            // 
            // LblEditId
            // 
            this.LblEditId.AutoSize = true;
            this.LblEditId.Location = new System.Drawing.Point(326, 364);
            this.LblEditId.Name = "LblEditId";
            this.LblEditId.Size = new System.Drawing.Size(19, 17);
            this.LblEditId.TabIndex = 20;
            this.LblEditId.Text = "id";
            // 
            // Items
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblEditId);
            this.Controls.Add(this.TbEditId);
            this.Controls.Add(this.LblDelete);
            this.Controls.Add(this.LblEditName);
            this.Controls.Add(this.LblEditAmount);
            this.Controls.Add(this.LblCreateName);
            this.Controls.Add(this.LblCreateAmount);
            this.Controls.Add(this.TbDelete);
            this.Controls.Add(this.TbEditName);
            this.Controls.Add(this.TbEditAmount);
            this.Controls.Add(this.TbCreateName);
            this.Controls.Add(this.TbCreateAmount);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.BtnEdit);
            this.Controls.Add(this.BtnCreate);
            this.Controls.Add(this.BtnShow);
            this.Controls.Add(this.BtnUsers);
            this.Controls.Add(this.BtnUserItems);
            this.Controls.Add(this.BtnTimer);
            this.Controls.Add(this.BtnLogout);
            this.Controls.Add(this.DgvItems);
            this.Name = "Items";
            this.Text = "Items";
            ((System.ComponentModel.ISupportInitialize)(this.DgvItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DgvItems;
        private System.Windows.Forms.Button BtnLogout;
        private System.Windows.Forms.Button BtnTimer;
        private System.Windows.Forms.Button BtnUserItems;
        private System.Windows.Forms.Button BtnUsers;
        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Button BtnCreate;
        private System.Windows.Forms.Button BtnEdit;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.TextBox TbCreateAmount;
        private System.Windows.Forms.TextBox TbCreateName;
        private System.Windows.Forms.TextBox TbEditAmount;
        private System.Windows.Forms.TextBox TbEditName;
        private System.Windows.Forms.TextBox TbDelete;
        private System.Windows.Forms.Label LblCreateAmount;
        private System.Windows.Forms.Label LblCreateName;
        private System.Windows.Forms.Label LblEditAmount;
        private System.Windows.Forms.Label LblEditName;
        private System.Windows.Forms.Label LblDelete;
        private System.Windows.Forms.TextBox TbEditId;
        private System.Windows.Forms.Label LblEditId;
    }
}