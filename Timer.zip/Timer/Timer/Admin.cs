﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Timer
{
    public static class Admin
    {
        public static int admin;
        public static int userid;
        public static string user;
        public static List<int> hoursid;
        public static List<int> hours;
    }
}
